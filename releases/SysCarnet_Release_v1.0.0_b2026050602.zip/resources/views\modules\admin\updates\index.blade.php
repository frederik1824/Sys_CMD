@extends('layouts.app')

@section('content')
<div class="p-6 lg:p-10 max-w-7xl mx-auto space-y-10 animate-in fade-in duration-700" x-data="healthMonitor()">
    <!-- Header Institucional -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div class="flex items-center gap-6">
            <div class="w-16 h-16 bg-slate-900 text-white rounded-[24px] flex items-center justify-center shadow-2xl shadow-slate-900/20">
                <i class="ph-duotone ph-arrows-clockwise text-3xl"></i>
            </div>
            <div>
                <h1 class="text-3xl font-black text-slate-900 tracking-tight mb-1">Centro de Actualizaciones</h1>
                <p class="text-slate-500 font-medium italic">Gestión de versiones, parches y salud del servidor On-Premise.</p>
            </div>
        </div>
        <div class="flex items-center gap-3">
            <button @click="createBackup()" class="inline-flex items-center gap-3 bg-white border border-slate-200 hover:border-slate-300 text-slate-600 px-6 py-3 rounded-2xl font-black uppercase text-xs tracking-widest transition-all shadow-sm">
                <i class="ph-bold ph-database text-lg text-emerald-500"></i>
                Backup Manual
            </button>
            <button @click="$refs.fileInput.click()" class="inline-flex items-center gap-3 bg-slate-900 hover:bg-black text-white px-6 py-3 rounded-2xl font-black uppercase text-xs tracking-widest transition-all shadow-lg active:scale-95">
                <i class="ph-bold ph-upload-simple text-lg"></i>
                Subir Parche
            </button>
            <input type="file" x-ref="fileInput" class="hidden" @change="uploadFile($event)">
        </div>
    </div>

    <!-- Grid de Monitoreo de Salud (Health Check) -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- CPU Card -->
        <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm group">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center">
                    <i class="ph-bold ph-cpu text-2xl"></i>
                </div>
                <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Carga CPU</span>
            </div>
            <p class="text-3xl font-black text-slate-900" x-text="metrics.server.cpu + '%'"></p>
            <div class="w-full h-1.5 bg-slate-100 rounded-full mt-4 overflow-hidden">
                <div class="h-full bg-indigo-500 transition-all duration-500" :style="'width: ' + metrics.server.cpu + '%'"></div>
            </div>
        </div>

        <!-- RAM Card -->
        <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm group">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center">
                    <i class="ph-bold ph-memory text-2xl"></i>
                </div>
                <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Memoria RAM</span>
            </div>
            <p class="text-3xl font-black text-slate-900" x-text="metrics.server.ram.percent + '%'"></p>
            <div class="w-full h-1.5 bg-slate-100 rounded-full mt-4 overflow-hidden">
                <div class="h-full bg-emerald-500 transition-all duration-500" :style="'width: ' + metrics.server.ram.percent + '%'"></div>
            </div>
        </div>

        <!-- DB Status -->
        <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm group">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center">
                    <i class="ph-bold ph-database text-2xl"></i>
                </div>
                <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest">MySQL Local</span>
            </div>
            <div class="flex items-baseline gap-2">
                <p class="text-3xl font-black text-slate-900" x-text="metrics.database.latency_ms + 'ms'"></p>
                <span class="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Online</span>
            </div>
        </div>

        <!-- Firebase Sync -->
        <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm group">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center">
                    <i class="ph-bold ph-cloud-arrow-up text-2xl"></i>
                </div>
                <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Firebase Sync</span>
            </div>
            <div class="flex items-center gap-2">
                <div class="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" x-show="metrics.firebase.status === 'online'"></div>
                <p class="text-3xl font-black text-slate-900" x-text="metrics.firebase.label"></p>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <!-- Columna de Historial de Versiones -->
        <div class="lg:col-span-2 space-y-6">
            <div class="bg-white rounded-[40px] border border-slate-100 shadow-xl overflow-hidden">
                <div class="p-8 border-b border-slate-50 flex items-center justify-between">
                    <h2 class="text-xl font-black text-slate-900 tracking-tight">Historial de Releases</h2>
                    <span class="bg-slate-100 text-slate-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">
                        v{{ $currentVersion->version ?? '1.0.0' }}
                    </span>
                </div>
                <div class="divide-y divide-slate-50">
                    @forelse($updates as $update)
                    <div class="p-8 hover:bg-slate-50/50 transition-colors flex items-start justify-between">
                        <div class="flex gap-6">
                            <div class="w-12 h-12 rounded-2xl bg-white border border-slate-100 flex items-center justify-center shadow-sm">
                                <i class="ph ph-git-commit text-slate-400 text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-black text-slate-900">Versión {{ $update->version }} <span class="text-slate-300 font-medium ml-2">#{{ $update->build_number }}</span></h4>
                                <p class="text-sm text-slate-500 mt-1">{{ $update->changelog }}</p>
                                <div class="flex items-center gap-3 mt-4">
                                    <span class="text-[9px] font-black uppercase px-2 py-1 bg-emerald-50 text-emerald-600 rounded border border-emerald-100">Exitoso</span>
                                    <span class="text-[9px] font-bold text-slate-400 uppercase italic">Aplicada el {{ $update->completed_at->format('d M, Y H:i') }}</span>
                                </div>
                            </div>
                        </div>
                        <button class="text-slate-300 hover:text-slate-900 transition-colors">
                            <i class="ph-bold ph-dots-three-vertical text-2xl"></i>
                        </button>
                    </div>
                    @empty
                    <div class="p-20 text-center">
                        <i class="ph ph-empty text-6xl text-slate-200 mb-4"></i>
                        <p class="text-slate-400 font-medium italic">No se han registrado actualizaciones en el servidor local.</p>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>

        <!-- Columna de Backups y Salud Extra -->
        <div class="space-y-6">
            <!-- Snapshots Recientes -->
            <div class="bg-white rounded-[40px] border border-slate-100 shadow-xl overflow-hidden">
                <div class="p-8 border-b border-slate-50">
                    <h2 class="text-lg font-black text-slate-900 tracking-tight">Snapshots de Seguridad</h2>
                </div>
                <div class="p-6 space-y-4">
                    @foreach($backups as $backup)
                    <div class="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between group">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                                <i class="ph ph-database text-slate-400"></i>
                            </div>
                            <div>
                                <p class="text-[10px] font-black text-slate-700 truncate max-w-[120px]">{{ $backup->filename }}</p>
                                <p class="text-[8px] font-bold text-slate-400 uppercase">{{ $backup->formatted_size }} • {{ $backup->created_at->diffForHumans() }}</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-1">
                            <button class="w-8 h-8 rounded-lg hover:bg-blue-500 hover:text-white text-slate-300 transition-all flex items-center justify-center">
                                <i class="ph-bold ph-download-simple"></i>
                            </button>
                            <button @click="confirmRollback('{{ $backup->id }}')" class="w-8 h-8 rounded-lg hover:bg-rose-500 hover:text-white text-slate-300 transition-all flex items-center justify-center" title="Restaurar este punto">
                                <i class="ph-bold ph-arrow-counter-clockwise"></i>
                            </button>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>

            <!-- Server Info -->
            <div class="bg-slate-900 rounded-[40px] p-8 text-white relative overflow-hidden">
                <div class="absolute -right-10 -bottom-10 opacity-10">
                    <i class="ph ph-terminal-window text-[180px]"></i>
                </div>
                <h3 class="text-xs font-black text-slate-400 uppercase tracking-widest mb-6">Información del Servidor</h3>
                <div class="space-y-4 relative z-10">
                    <div class="flex justify-between items-center border-b border-white/5 pb-3">
                        <span class="text-[10px] font-bold text-slate-400 uppercase">OS</span>
                        <span class="text-[10px] font-black" x-text="metrics.server.os"></span>
                    </div>
                    <div class="flex justify-between items-center border-b border-white/5 pb-3">
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Uptime</span>
                        <span class="text-[10px] font-black" x-text="metrics.uptime"></span>
                    </div>
                    <div class="flex justify-between items-center border-b border-white/5 pb-3">
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Almacenamiento</span>
                        <span class="text-[10px] font-black" x-text="metrics.server.disk.percent + '% usado'"></span>
                    </div>
                </div>

                <div class="mt-8 pt-6 border-t border-white/5">
                    <h4 class="text-[8px] font-black text-blue-400 uppercase tracking-widest mb-4">Estatus de Servicios</h4>
                    <div class="grid grid-cols-2 gap-2">
                        <template x-for="service in metrics.services" :key="service.name">
                            <div class="bg-white/5 rounded-xl p-3 flex flex-col gap-1">
                                <span class="text-[8px] font-bold text-slate-500 uppercase" x-text="service.name"></span>
                                <div class="flex items-center gap-2">
                                    <div class="w-1.5 h-1.5 rounded-full" :class="service.status === 'running' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-rose-500'"></div>
                                    <span class="text-[9px] font-black uppercase" :class="service.status === 'running' ? 'text-emerald-400' : 'text-rose-400'" x-text="service.status"></span>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function healthMonitor() {
    return {
        metrics: {
            server: { cpu: 0, ram: { percent: 0 }, disk: { percent: 0 }, os: '...' },
            database: { latency_ms: 0, status: 'online' },
            firebase: { status: 'online', label: 'Consultando...' },
            uptime: '...'
        },
        init() {
            this.refreshMetrics();
            setInterval(() => this.refreshMetrics(), 10000);
        },
        async refreshMetrics() {
            try {
                const response = await fetch("{{ route('admin.updates.health') }}");
                this.metrics = await response.json();
            } catch (error) {
                console.error("Error fetching health metrics:", error);
            }
        },
        async createBackup() {
            Swal.fire({
                title: 'Generando Snapshot',
                text: 'Por favor espera mientras respaldamos la base de datos...',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading() }
            });

            try {
                const response = await fetch("{{ route('admin.updates.backup') }}", {
                    method: 'POST',
                    headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
                });
                const data = await response.json();
                if (data.success) {
                    Swal.fire('¡Éxito!', data.message, 'success').then(() => window.location.reload());
                } else {
                    throw new Error(data.message);
                }
            } catch (error) {
                Swal.fire('Error', error.message, 'error');
            }
        },
        uploadFile(event) {
            const file = event.target.files[0];
            if (!file) return;

            Swal.fire({
                title: '¿Subir actualización?',
                text: `Vas a cargar el paquete: ${file.name}`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Sí, subir',
                confirmButtonColor: '#0f172a'
            }).then((result) => {
                if (result.isConfirmed) {
                    this.performUpload(file);
                }
            });
        },
        async performUpload(file) {
            const formData = new FormData();
            formData.append('patch', file);

            Swal.fire({
                title: 'Subiendo paquete',
                html: 'Enviando archivos al servidor local...',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading() }
            });

            try {
                const response = await fetch("{{ route('admin.updates.upload') }}", {
                    method: 'POST',
                    headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                    body: formData
                });
                const data = await response.json();
                if (data.success) {
                    Swal.fire({
                        title: 'Paquete Validado',
                        text: 'El sistema está listo para aplicar la actualización. Se entrará en modo mantenimiento.',
                        icon: 'success',
                        showCancelButton: true,
                        confirmButtonText: 'Aplicar Ahora (Peligroso)',
                        confirmButtonColor: '#ef4444'
                    }).then((res) => {
                        if (res.isConfirmed) {
                            this.applyUpdate(data.temp_path);
                        }
                    });
                } else {
                    throw new Error(data.message);
                }
            } catch (error) {
                Swal.fire('Fallo de Carga', error.message, 'error');
            }
        },
        async applyUpdate(tempPath) {
            Swal.fire({
                title: 'Aplicando Actualización',
                html: 'Este proceso puede tardar. No cierres el navegador.',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading() }
            });

            try {
                const response = await fetch("{{ url('admin/updates/apply') }}", {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' 
                    },
                    body: JSON.stringify({ temp_path: tempPath })
                });
                const data = await response.json();
                if (data.success) {
                    Swal.fire('¡Sistema Actualizado!', data.message, 'success').then(() => {
                        window.location.reload();
                    });
                } else {
                    throw new Error(data.message);
                }
            } catch (error) {
                Swal.fire('Fallo en Despliegue', error.message, 'error');
            }
        },
        async confirmRollback(id) {
            const result = await Swal.fire({
                title: '¿Confirmar Restauración?',
                text: 'Esta acción sobrescribirá la base de datos actual con este snapshot. ¡Es irreversible!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Sí, Restaurar Ahora',
                confirmButtonColor: '#e11d48',
                cancelButtonText: 'Cancelar'
            });

            if (result.isConfirmed) {
                Swal.fire({ title: 'Restaurando...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

                try {
                    const response = await fetch(`{{ url('admin/updates/rollback') }}/${id}`, {
                        method: 'POST',
                        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
                    });
                    const data = await response.json();
                    if (data.success) {
                        Swal.fire('¡Restaurado!', data.message, 'success').then(() => window.location.reload());
                    } else {
                        throw new Error(data.message);
                    }
                } catch (error) {
                    Swal.fire('Fallo Crítico', error.message, 'error');
                }
            }
        }
    }
}
</script>
@endsection
