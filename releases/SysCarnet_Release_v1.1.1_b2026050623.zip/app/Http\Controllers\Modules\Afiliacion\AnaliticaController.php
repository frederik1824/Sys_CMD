<?php

namespace App\Http\Controllers\Modules\Afiliacion;

use App\Http\Controllers\Controller;
use App\Models\SolicitudAfiliacion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class AnaliticaController extends Controller
{
    public function index(Request $request)
    {
        $periodo = $request->periodo ?: 'month'; // 'month', 'quarter', 'year'
        $startDate = match($periodo) {
            'year' => now()->startOfYear(),
            'quarter' => now()->subMonths(3),
            default => now()->startOfMonth(),
        };

        // 1. KPI: Tiempo Promedio de Afiliación (Turnaround Time - TAT)
        // Solo para solicitudes completadas
        $tatPromedio = SolicitudAfiliacion::where('estado', 'Completada')
            ->where('fecha_cierre', '>=', $startDate)
            ->select(DB::raw('AVG(TIMESTAMPDIFF(HOUR, created_at, fecha_cierre)) as hours'))
            ->first()->hours ?: 0;

        // 2. KPI: Tasa de Rechazo
        $totalFinalizadas = SolicitudAfiliacion::whereIn('estado', ['Completada', 'Rechazada'])
            ->where('fecha_cierre', '>=', $startDate)
            ->count();
        $totalRechazadas = SolicitudAfiliacion::where('estado', 'Rechazada')
            ->where('fecha_cierre', '>=', $startDate)
            ->count();
        $tasaRechazo = $totalFinalizadas > 0 ? ($totalRechazadas / $totalFinalizadas) * 100 : 0;

        // 3. KPI: Resolución en Primer Intento (FCR)
        $completadasEnPeriodo = SolicitudAfiliacion::where('estado', 'Completada')
            ->where('fecha_cierre', '>=', $startDate)
            ->count();
        $completadasFCR = SolicitudAfiliacion::where('estado', 'Completada')
            ->where('es_primera_resolucion', true)
            ->where('fecha_cierre', '>=', $startDate)
            ->count();
        $tasaFCR = $completadasEnPeriodo > 0 ? ($completadasFCR / $completadasEnPeriodo) * 100 : 0;

        // 4. KPI: Nivel de Satisfacción (CSAT)
        $csatPromedio = SolicitudAfiliacion::whereNotNull('satisfaccion_nivel')
            ->where('fecha_cierre', '>=', $startDate)
            ->avg('satisfaccion_nivel') ?: 0;

        // 5. Métricas por Tipo de Solicitud (Especialmente Pensionados)
        $metricasPorTipo = SolicitudAfiliacion::where('fecha_cierre', '>=', $startDate)
            ->join('tipos_solicitud_afiliacion', 'solicitudes_afiliacion.tipo_solicitud_id', '=', 'tipos_solicitud_afiliacion.id')
            ->select(
                'tipos_solicitud_afiliacion.nombre',
                DB::raw('count(*) as total'),
                DB::raw('AVG(TIMESTAMPDIFF(HOUR, solicitudes_afiliacion.created_at, solicitudes_afiliacion.fecha_cierre)) as tat')
            )
            ->whereIn('solicitudes_afiliacion.estado', ['Completada'])
            ->groupBy('tipos_solicitud_afiliacion.nombre')
            ->get();

        // 6. Tendencia Mensual (Volumen)
        $tendencia = SolicitudAfiliacion::select(
                DB::raw('DATE_FORMAT(created_at, "%Y-%m") as mes'),
                DB::raw('count(*) as total'),
                DB::raw('SUM(CASE WHEN estado = "Completada" THEN 1 ELSE 0 END) as completadas')
            )
            ->where('created_at', '>=', now()->subMonths(6))
            ->groupBy('mes')
            ->orderBy('mes')
            ->get();

        return view('modules.afiliacion.analytics', compact(
            'tatPromedio', 'tasaRechazo', 'tasaFCR', 'csatPromedio', 
            'metricasPorTipo', 'tendencia', 'periodo'
        ));
    }
}
