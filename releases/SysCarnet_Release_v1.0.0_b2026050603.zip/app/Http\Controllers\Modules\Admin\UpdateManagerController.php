<?php

namespace App\Http\Controllers\Modules\Admin;

use App\Http\Controllers\Controller;
use App\Models\SystemUpdate;
use App\Models\SystemBackup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use ZipArchive;

class UpdateManagerController extends Controller
{
    public function index()
    {
        $updates = SystemUpdate::with('executor')->orderBy('build_number', 'desc')->get();
        $backups = SystemBackup::with('creator')->orderBy('created_at', 'desc')->get();
        $currentVersion = $updates->where('status', 'success')->first();
        
        // Obtener archivos generados en /releases
        $releasesPath = base_path('releases');
        $generatedReleases = [];
        if (File::exists($releasesPath)) {
            $files = File::files($releasesPath);
            foreach ($files as $file) {
                if ($file->getExtension() === 'zip') {
                    $generatedReleases[] = [
                        'name' => $file->getFilename(),
                        'size' => round($file->getSize() / 1024 / 1024, 2) . ' MB',
                        'date' => date('d/m/Y H:i', $file->getMTime()),
                        'timestamp' => $file->getMTime()
                    ];
                }
            }
            // Ordenar por fecha descendente
            usort($generatedReleases, function($a, $b) {
                return $b['timestamp'] - $a['timestamp'];
            });
        }

        return view('modules.admin.updates.index', compact('updates', 'backups', 'currentVersion', 'generatedReleases'));
    }

    public function pack(Request $request)
    {
        try {
            $version = $request->input('version');
            $changelog = $request->input('changelog', 'Actualización general del sistema.');

            // Ejecutar el comando artisan
            $exitCode = Artisan::call('release:pack', [
                '--ver' => $version
            ]);

            if ($exitCode === 0) {
                return response()->json(['success' => true, 'message' => 'Paquete generado exitosamente en /releases']);
            }

            throw new \Exception("Error al ejecutar el empaquetador.");
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function downloadRelease($filename)
    {
        $path = base_path('releases/' . $filename);
        if (File::exists($path)) {
            return response()->download($path);
        }
        abort(404);
    }

    public function createBackup(Request $request)
    {
        try {
            $filename = 'backup_' . now()->format('Y_m_d_His') . '.sql';
            $path = 'backups/' . $filename;
            
            if (!Storage::disk('local')->exists('backups')) {
                Storage::disk('local')->makeDirectory('backups');
            }

            // Comando para mysqldump
            $dbConfig = config('database.connections.mysql');
            $command = sprintf(
                'mysqldump --user=%s --password=%s --host=%s %s > %s',
                escapeshellarg($dbConfig['username']),
                escapeshellarg($dbConfig['password']),
                escapeshellarg($dbConfig['host']),
                escapeshellarg($dbConfig['database']),
                Storage::disk('local')->path($path)
            );

            exec($command, $output, $returnVar);

            if ($returnVar !== 0) {
                throw new \Exception("Fallo al ejecutar mysqldump. Verifica permisos.");
            }

            $backup = SystemBackup::create([
                'filename' => $filename,
                'path' => $path,
                'type' => 'manual',
                'size_bytes' => Storage::disk('local')->size($path),
                'status' => 'success',
                'created_by' => auth()->id(),
            ]);

            $this->cleanupOldBackups();

            return response()->json(['success' => true, 'message' => 'Snapshot creado correctamente.', 'backup' => $backup]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function rollback(Request $request, SystemBackup $backup)
    {
        try {
            if (!Storage::disk('local')->exists($backup->path)) {
                throw new \Exception("El archivo de backup no existe físicamente.");
            }

            // 1. Bloqueo
            \Illuminate\Support\Facades\Cache::put('system_update_lock', true, now()->addMinutes(10));

            // 2. Restaurar DB
            $dbConfig = config('database.connections.mysql');
            $command = sprintf(
                'mysql --user=%s --password=%s --host=%s %s < %s',
                escapeshellarg($dbConfig['username']),
                escapeshellarg($dbConfig['password']),
                escapeshellarg($dbConfig['host']),
                escapeshellarg($dbConfig['database']),
                Storage::disk('local')->path($backup->path)
            );

            exec($command, $output, $returnVar);

            if ($returnVar !== 0) {
                throw new \Exception("Fallo al restaurar la base de datos.");
            }

            // 3. Limpiar Caché
            Artisan::call('optimize:clear');

            // 4. Desbloqueo
            \Illuminate\Support\Facades\Cache::forget('system_update_lock');

            return response()->json(['success' => true, 'message' => 'Sistema restaurado con éxito al punto: ' . $backup->created_at->format('d/m/Y H:i')]);

        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Cache::forget('system_update_lock');
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    private function cleanupOldBackups()
    {
        $oldBackups = SystemBackup::orderBy('created_at', 'desc')->skip(15)->get();
        foreach ($oldBackups as $old) {
            Storage::disk('local')->delete($old->path);
            $old->delete();
        }
    }

    public function uploadUpdate(Request $request)
    {
        $request->validate([
            'update_file' => 'required|file|mimes:zip|max:51200', // 50MB
        ]);

        try {
            $file = $request->file('update_file');
            $path = $file->store('updates_temp', 'local');
            
            // Aquí iría la lógica de validación de integridad (SHA256, etc)
            
            return response()->json([
                'success' => true, 
                'message' => 'Paquete recibido y validado. Listo para aplicar.',
                'temp_path' => $path
            ]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function applyUpdate(Request $request)
    {
        $tempPath = $request->input('temp_path');
        
        if (!Storage::disk('local')->exists($tempPath)) {
            return response()->json(['success' => false, 'message' => 'Archivo temporal no encontrado.'], 404);
        }

        try {
            // 1. Activar Modo Mantenimiento Personalizado
            \Illuminate\Support\Facades\Cache::put('system_update_lock', true, now()->addMinutes(30));

            // 2. Ejecutar Backup Pre-vuelo (DB)
            $backupResponse = $this->createBackup($request);
            if (!$backupResponse->getData()->success) {
                throw new \Exception("Fallo al crear el backup preventivo.");
            }

            // 3. Extraer ZIP
            $zipPath = Storage::disk('local')->path($tempPath);
            $extractPath = storage_path('app/updates_extract_' . time());
            
            $zip = new ZipArchive;
            if ($zip->open($zipPath) === TRUE) {
                $zip->extractTo($extractPath);
                $zip->close();
            } else {
                throw new \Exception("No se pudo abrir el archivo ZIP.");
            }

            // 4. Mover archivos (Sincronización Atómica Manual)
            // NOTA: En un entorno ideal usaríamos rsync, aquí lo haremos por PHP
            $this->recursiveCopy($extractPath, base_path());

            // 5. Ejecutar Comandos de Mantenimiento
            Artisan::call('migrate', ['--force' => true]);
            Artisan::call('optimize:clear');
            Artisan::call('config:cache');
            Artisan::call('route:cache');
            Artisan::call('view:cache');

            // 6. Registrar Actualización en DB
            $versionInfo = json_decode(file_get_contents(base_path('version.json')), true);
            SystemUpdate::create([
                'version' => $versionInfo['version'] ?? 'unknown',
                'build_number' => $versionInfo['build'] ?? time(),
                'type' => 'patch',
                'status' => 'success',
                'completed_at' => now(),
                'executed_by' => auth()->id(),
            ]);

            // 7. Desactivar Mantenimiento
            \Illuminate\Support\Facades\Cache::forget('system_update_lock');

            return response()->json([
                'success' => true, 
                'message' => 'Actualización aplicada con éxito. El sistema se ha reiniciado.'
            ]);

        } catch (\Exception $e) {
            \Illuminate\Support\Facades\Cache::forget('system_update_lock');
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    private function recursiveCopy($src, $dst)
    {
        $dir = opendir($src);
        @mkdir($dst);
        while (false !== ($file = readdir($dir))) {
            if (($file != '.') && ($file != '..')) {
                if (is_dir($src . '/' . $file)) {
                    $this->recursiveCopy($src . '/' . $file, $dst . '/' . $file);
                } else {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }
}
