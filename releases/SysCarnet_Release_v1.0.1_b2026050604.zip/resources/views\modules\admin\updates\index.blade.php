@extends('layouts.app')

@section('content')
<div class="p-6 lg:p-10 max-w-7xl mx-auto space-y-10 animate-in fade-in duration-700" 
     x-data="{ 
        tab: window.location.hash ? window.location.hash.replace('#', '') : 'releases',
        ...healthMonitor() 
     }"
     x-init="window.addEventListener('hashchange', () => { tab = window.location.hash.replace('#', '') || 'releases' })">
    
    <!-- Header Institucional -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div class="flex items-center gap-6">
            <div class="w-16 h-16 bg-slate-900 text-white rounded-[24px] flex items-center justify-center shadow-2xl shadow-slate-900/20">
                <i class="ph-duotone" :class="tab === 'health' ? 'ph-activity' : (tab === 'backups' ? 'ph-database' : 'ph-rocket-launch')" style="font-size: 32px;"></i>
            </div>
            <div>
                <h1 class="text-3xl font-black text-slate-900 tracking-tight" x-text="tab === 'health' ? 'Monitor de Salud' : (tab === 'backups' ? 'Snapshots & Backups' : 'Release Manager')"></h1>
                <p class="text-slate-500 font-medium flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    Centro de Control On-Premise
                </p>
            </div>
        </div>

        <div class="flex items-center gap-3 bg-white p-1.5 rounded-[20px] border border-slate-100 shadow-sm">
            <button @click="tab = 'releases'; window.location.hash = 'releases'" :class="tab === 'releases' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'" class="px-6 py-2.5 rounded-[16px] text-xs font-black uppercase tracking-widest transition-all">Releases</button>
            <button @click="tab = 'health'; window.location.hash = 'health'" :class="tab === 'health' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'" class="px-6 py-2.5 rounded-[16px] text-xs font-black uppercase tracking-widest transition-all">Salud</button>
            <button @click="tab = 'backups'; window.location.hash = 'backups'" :class="tab === 'backups' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'" class="px-6 py-2.5 rounded-[16px] text-xs font-black uppercase tracking-widest transition-all">Snapshots</button>
            <button @click="tab = 'logs'; window.location.hash = 'logs'; fetchLogs()" :class="tab === 'logs' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'" class="px-6 py-2.5 rounded-[16px] text-xs font-black uppercase tracking-widest transition-all">Logs</button>
            <button @click="tab = 'packer'; window.location.hash = 'packer'" :class="tab === 'packer' ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'" class="px-6 py-2.5 rounded-[16px] text-xs font-black uppercase tracking-widest transition-all">Packer</button>
        </div>
    </div>

    <!-- VISTA: PACKER -->
    <div x-show="tab === 'packer'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="grid grid-cols-1 lg:grid-cols-3 gap-8" x-cloak>
        <div class="lg:col-span-2 space-y-8">
            <div class="bg-white rounded-[40px] border border-slate-100 shadow-xl overflow-hidden">
                <div class="p-10 border-b border-slate-50">
                    <h2 class="text-xl font-black text-slate-900 mb-2">Generar Nuevo Paquete de Release</h2>
                    <p class="text-slate-500 text-sm">Prepara el estado actual del sistema para ser distribuido a servidores locales.</p>
                </div>
                <div class="p-10 space-y-6">
                    <div class="grid grid-cols-2 gap-6">
                        <div>
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Versión Target</label>
                            <input type="text" x-model="packVersion" class="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 font-bold text-slate-700 outline-none focus:ring-2 focus:ring-blue-500/20 transition-all">
                        </div>
                        <div>
                            <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Build Sugerido</label>
                            <div class="w-full bg-slate-100 border border-slate-200 rounded-2xl px-6 py-4 font-bold text-slate-400">
                                #{{ ($currentVersion->build_number ?? 0) + 1 }}
                            </div>
                        </div>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Notas de la Versión (Changelog)</label>
                        <textarea x-model="packChangelog" rows="4" class="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-4 font-bold text-slate-700 outline-none focus:ring-2 focus:ring-blue-500/20 transition-all" placeholder="Ej: Corrección de errores en reporte de nómina..."></textarea>
                    </div>
                    <button @click="generatePack()" class="w-full bg-blue-600 text-white py-5 rounded-[24px] font-black uppercase tracking-[2px] text-xs hover:bg-slate-900 shadow-xl shadow-blue-200 transition-all flex items-center justify-center gap-3">
                        <i class="ph-bold ph-package text-xl"></i>
                        Empaquetar Release Ahora
                    </button>
                </div>
            </div>

            <!-- Lista de Releases Generados -->
            <div class="bg-white rounded-[40px] border border-slate-100 shadow-xl overflow-hidden">
                <div class="p-8 border-b border-slate-50">
                    <h3 class="text-lg font-black text-slate-900">Bundles Generados Localmente</h3>
                </div>
                <div class="divide-y divide-slate-50">
                    @forelse($generatedReleases as $release)
                    <div class="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                        <div class="flex items-center gap-4">
                            <div class="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center">
                                <i class="ph-bold ph-file-zip text-blue-500 text-xl"></i>
                            </div>
                            <div>
                                <p class="font-black text-slate-800 text-sm">{{ $release['name'] }}</p>
                                <p class="text-[10px] font-bold text-slate-400 uppercase">{{ $release['size'] }} • {{ $release['date'] }}</p>
                            </div>
                        </div>
                        <a href="{{ route('admin.updates.download_release', $release['name']) }}" class="w-12 h-12 rounded-2xl border border-slate-100 flex items-center justify-center text-slate-400 hover:bg-slate-900 hover:text-white hover:border-slate-900 transition-all">
                            <i class="ph-bold ph-download-simple"></i>
                        </a>
                    </div>
                    @empty
                    <div class="p-20 text-center text-slate-400 italic">No hay paquetes generados en la carpeta /releases.</div>
                    @endforelse
                </div>
            </div>
        </div>

        <div class="space-y-6">
            <div class="bg-blue-600 rounded-[40px] p-8 text-white shadow-2xl relative overflow-hidden">
                <div class="absolute -right-5 -bottom-5 opacity-10">
                    <i class="ph ph-package text-[140px]"></i>
                </div>
                <h3 class="text-xs font-black text-blue-100 uppercase tracking-widest mb-4">Mantenimiento de Disco</h3>
                <p class="text-sm text-blue-50 font-medium leading-relaxed mb-6">
                    Libera espacio borrando archivos temporales de actualizaciones y purga la caché del servidor.
                </p>
                <button @click="purgeSystem()" class="w-full bg-white/10 hover:bg-white/20 text-white py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
                    Ejecutar Limpieza Profunda
                </button>
            </div>
        </div>
    </div>

    <!-- VISTA: RELEASES -->
    <div x-show="tab === 'releases'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Panel de Aplicación de Parches -->
        <div class="lg:col-span-2 space-y-8">
            <!-- Semáforo de Dependencias -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm flex items-center gap-4">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center" :class="'{{ $requirements['php']['status'] }}' === 'ok' ? 'bg-emerald-50 text-emerald-500' : 'bg-rose-50 text-rose-500'">
                        <i class="ph-bold ph-cpu text-xl"></i>
                    </div>
                    <div>
                        <p class="text-[10px] font-black text-slate-400 uppercase">PHP Version</p>
                        <p class="text-sm font-black text-slate-700">{{ $requirements['php']['version'] }}</p>
                    </div>
                </div>
                <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm flex items-center gap-4">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center" :class="'{{ $requirements['disk']['status'] }}' === 'ok' ? 'bg-emerald-50 text-emerald-500' : 'bg-rose-50 text-rose-500'">
                        <i class="ph-bold ph-hard-drive text-xl"></i>
                    </div>
                    <div>
                        <p class="text-[10px] font-black text-slate-400 uppercase">Disco Libre</p>
                        <p class="text-sm font-black text-slate-700">{{ $requirements['disk']['free'] }}</p>
                    </div>
                </div>
                <div class="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm flex items-center gap-4">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center {{ $requirements['extensions']['zip'] && $requirements['extensions']['gd'] ? 'bg-emerald-50 text-emerald-500' : 'bg-rose-50 text-rose-500' }}">
                        <i class="ph-bold ph-brackets-curly text-xl"></i>
                    </div>
                    <div>
                        <p class="text-[10px] font-black text-slate-400 uppercase">Extensiones</p>
                        <p class="text-[10px] font-black {{ $requirements['extensions']['zip'] ? 'text-emerald-600' : 'text-rose-600' }}">ZIP: {{ $requirements['extensions']['zip'] ? 'OK' : 'FALTA' }}</p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-[40px] border border-slate-100 shadow-xl overflow-hidden group">
                <div class="p-10 border-b border-slate-50 relative overflow-hidden">
                    <div class="absolute top-0 right-0 p-10 opacity-[0.03] group-hover:scale-110 transition-transform duration-700">
                        <i class="ph ph-upload-simple text-[120px]"></i>
                    </div>
                    <div class="relative z-10">
                        <h2 class="text-xl font-black text-slate-900 mb-2">Desplegar Nueva Actualización</h2>
                        <p class="text-slate-500 text-sm mb-8 max-w-md">Sube el paquete de parche (.zip) generado por el empaquetador oficial para aplicar cambios al núcleo del sistema.</p>
                        
                        <div class="flex flex-col gap-4">
                            <label class="relative group cursor-pointer">
                                <input type="file" class="hidden" @change="handleFile($event)">
                                <div class="w-full h-32 border-2 border-dashed border-slate-200 rounded-[32px] flex flex-col items-center justify-center gap-2 group-hover:border-blue-400 group-hover:bg-blue-50/50 transition-all">
                                    <template x-if="!file">
                                        <div class="flex flex-col items-center">
                                            <i class="ph ph-plus-circle text-2xl text-slate-400 group-hover:text-blue-500 mb-1"></i>
                                            <span class="text-[10px] font-black uppercase text-slate-400 tracking-widest">Seleccionar Archivo .ZIP</span>
                                        </div>
                                    </template>
                                    <template x-if="file">
                                        <div class="flex items-center gap-3 bg-white px-6 py-3 rounded-2xl shadow-sm border border-blue-100">
                                            <i class="ph ph-file-zip text-2xl text-blue-500"></i>
                                            <span class="text-sm font-bold text-slate-700" x-text="file.name"></span>
                                        </div>
                                    </template>
                                </div>
                            </label>

                            <button x-show="file" 
                                    @click="uploadUpdate()"
                                    class="w-full bg-slate-900 text-white py-4 rounded-[24px] font-black uppercase tracking-[2px] text-xs hover:bg-blue-600 shadow-xl transition-all flex items-center justify-center gap-3">
                                <i class="ph-bold ph-rocket-launch text-lg"></i>
                                Iniciar Despliegue de Patch
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Historial de Updates -->
            <div class="bg-white rounded-[40px] border border-slate-100 shadow-xl overflow-hidden">
                <div class="p-8 border-b border-slate-50 flex items-center justify-between">
                    <h3 class="text-lg font-black text-slate-900 tracking-tight">Registro de Cambios del Servidor</h3>
                </div>
                <div class="divide-y divide-slate-50">
                    @forelse($updates as $update)
                    <div class="p-8 hover:bg-slate-50/50 transition-colors flex items-start justify-between">
                        <div class="flex gap-6">
                            <div class="w-12 h-12 rounded-2xl bg-white border border-slate-100 flex items-center justify-center shadow-sm">
                                <i class="ph ph-git-commit text-slate-400 text-xl"></i>
                            </div>
                            <div>
                                <h4 class="font-black text-slate-900">Versión {{ $update->version }} <span class="text-slate-300 font-medium ml-2">#{{ $update->build_number }}</span></h4>
                                <p class="text-sm text-slate-500 mt-1">{{ $update->changelog }}</p>
                                <div class="flex items-center gap-3 mt-4">
                                    <span class="text-[9px] font-black uppercase px-2 py-1 bg-emerald-50 text-emerald-600 rounded border border-emerald-100">Exitoso</span>
                                    <span class="text-[9px] font-bold text-slate-400 uppercase italic">Aplicada el {{ $update->completed_at->format('d M, Y H:i') }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    @empty
                    <div class="p-20 text-center">
                        <i class="ph ph-empty text-6xl text-slate-200 mb-4"></i>
                        <p class="text-slate-400 font-medium italic">No se han registrado actualizaciones en el servidor local.</p>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>

        <!-- Sidebar Informativo -->
        <div class="space-y-6">
            <div class="bg-slate-900 rounded-[40px] p-10 text-white shadow-2xl relative overflow-hidden">
                <div class="absolute -right-10 -bottom-10 opacity-10">
                    <i class="ph ph-info text-[180px]"></i>
                </div>
                <h3 class="text-xs font-black text-blue-400 uppercase tracking-widest mb-6">Versión Actual</h3>
                <div class="mb-8">
                    <span class="text-5xl font-black">{{ $currentVersion->version ?? '1.0.0' }}</span>
                    <p class="text-slate-400 mt-2 font-bold tracking-widest uppercase text-[10px]">Build #{{ $currentVersion->build_number ?? '0' }}</p>
                </div>
                <div class="space-y-4 pt-6 border-t border-white/10">
                    <div class="flex justify-between items-center">
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Estado</span>
                        <span class="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Protegido</span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Seguridad</span>
                        <span class="text-[10px] font-black text-blue-400 uppercase tracking-widest">Atómica</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- VISTA: SALUD -->
    <div x-show="tab === 'health'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="grid grid-cols-1 lg:grid-cols-2 gap-8" x-cloak>
        <div class="bg-slate-900 rounded-[40px] p-10 text-white shadow-2xl space-y-10">
            <div class="grid grid-cols-2 gap-8">
                <div class="space-y-2">
                    <span class="text-[10px] font-bold text-slate-500 uppercase tracking-[2px]">Uso de CPU</span>
                    <div class="flex items-end gap-3">
                        <span class="text-4xl font-black" x-text="metrics.server.cpu + '%'"></span>
                        <div class="w-full bg-white/10 h-1.5 rounded-full mb-2">
                            <div class="bg-blue-500 h-full rounded-full transition-all duration-1000" :style="'width: ' + metrics.server.cpu + '%'"></div>
                        </div>
                    </div>
                </div>
                <div class="space-y-2">
                    <span class="text-[10px] font-bold text-slate-500 uppercase tracking-[2px]">Memoria RAM</span>
                    <div class="flex items-end gap-3">
                        <span class="text-4xl font-black" x-text="metrics.server.ram.percent + '%'"></span>
                        <div class="w-full bg-white/10 h-1.5 rounded-full mb-2">
                            <div class="bg-emerald-500 h-full rounded-full transition-all duration-1000" :style="'width: ' + metrics.server.ram.percent + '%'"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="pt-10 border-t border-white/5 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                <div class="p-6 bg-white/5 rounded-3xl">
                    <p class="text-[9px] font-bold text-slate-500 uppercase mb-2">Latencia DB</p>
                    <p class="text-xl font-black text-blue-400" x-text="metrics.database.latency_ms + 'ms'"></p>
                </div>
                <div class="p-6 bg-white/5 rounded-3xl border border-white/5" :class="'{{ $cronStatus['status'] }}' === 'online' ? 'border-emerald-500/30' : 'border-rose-500/30'">
                    <p class="text-[9px] font-bold text-slate-500 uppercase mb-2">Cron (Pulso)</p>
                    <p class="text-xl font-black uppercase" :class="'{{ $cronStatus['status'] }}' === 'online' ? 'text-emerald-400' : 'text-rose-400'">{{ $cronStatus['label'] }}</p>
                </div>
                <div class="p-6 bg-white/5 rounded-3xl">
                    <p class="text-[9px] font-bold text-slate-500 uppercase mb-2">Sesiones Activas</p>
                    <p class="text-xl font-black text-blue-400">{{ $activeSessions }}</p>
                </div>
                <div class="p-6 bg-white/5 rounded-3xl">
                    <p class="text-[9px] font-bold text-slate-500 uppercase mb-2">Google Sync</p>
                    <p class="text-xl font-black text-emerald-400" x-text="metrics.firebase.latency_ms + 'ms'"></p>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-[40px] border border-slate-100 shadow-xl p-10">
            <h3 class="text-lg font-black text-slate-900 mb-8 tracking-tight">Estatus de Servicios Locales</h3>
            <div class="grid grid-cols-1 gap-4">
                <template x-for="service in metrics.services" :key="service.name">
                    <div class="flex items-center justify-between p-6 bg-slate-50 rounded-[24px] border border-slate-100">
                        <div class="flex items-center gap-4">
                            <div class="w-10 h-10 rounded-xl bg-white border border-slate-100 flex items-center justify-center shadow-sm">
                                <i class="ph ph-gear text-slate-400"></i>
                            </div>
                            <span class="font-black text-slate-700 text-sm tracking-tight" x-text="service.name"></span>
                        </div>
                        <div class="flex items-center gap-2 px-4 py-2 rounded-full" :class="service.status === 'running' ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'">
                            <div class="w-1.5 h-1.5 rounded-full" :class="service.status === 'running' ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'"></div>
                            <span class="text-[10px] font-black uppercase tracking-widest" x-text="service.status"></span>
                        </div>
                    </div>
                </template>
            </div>
        </div>
    </div>

    <!-- VISTA: LOGS -->
    <div x-show="tab === 'logs'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="space-y-6" x-cloak>
        <div class="bg-slate-900 rounded-[40px] p-10 text-white shadow-2xl relative overflow-hidden">
            <div class="flex items-center justify-between mb-8">
                <div>
                    <h2 class="text-xl font-black tracking-tight">Explorador de Logs (laravel.log)</h2>
                    <p class="text-slate-500 text-xs font-bold uppercase tracking-widest mt-1">Últimas 100 líneas del servidor</p>
                </div>
                <button @click="fetchLogs()" class="bg-white/10 hover:bg-white/20 px-6 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">Refrescar</button>
            </div>
            <div class="bg-black/50 rounded-[32px] p-8 h-[500px] overflow-y-auto font-mono text-[11px] leading-relaxed border border-white/5" id="log-viewer">
                <pre class="whitespace-pre-wrap text-emerald-500/80" x-text="systemLogs"></pre>
            </div>
        </div>
    </div>

    <!-- VISTA: SNAPSHOTS -->
    <div x-show="tab === 'backups'" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="space-y-8" x-cloak>
        <div class="bg-white rounded-[40px] border border-slate-100 shadow-xl overflow-hidden">
            <div class="p-8 border-b border-slate-50 flex items-center justify-between">
                <h2 class="text-lg font-black text-slate-900 tracking-tight">Snapshots de Seguridad</h2>
                <button @click="createBackup()" class="bg-slate-900 text-white px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[2px] hover:bg-blue-600 transition-all">Crear Punto de Restauración</button>
            </div>
            <div class="p-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                @forelse($backups as $backup)
                <div class="p-6 bg-slate-50 rounded-[32px] border border-slate-100 flex flex-col gap-6 group hover:bg-white hover:shadow-xl hover:scale-[1.02] transition-all">
                    <div class="flex items-center justify-between">
                        <div class="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm">
                            <i class="ph" :class="'{{ $backup->type }}' === 'code' ? 'ph-code-block text-blue-500' : 'ph-database text-rose-500'"></i>
                        </div>
                        <div class="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button class="w-10 h-10 rounded-xl bg-slate-100 text-slate-600 flex items-center justify-center hover:bg-slate-900 hover:text-white transition-all">
                                <i class="ph-bold ph-download-simple"></i>
                            </button>
                            <button @click="confirmRollback('{{ $backup->id }}')" class="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center hover:bg-rose-600 hover:text-white transition-all">
                                <i class="ph-bold ph-arrow-counter-clockwise"></i>
                            </button>
                        </div>
                    </div>
                    <div>
                        <div class="flex items-center gap-2 mb-1">
                            <span class="text-[8px] font-black uppercase px-1.5 py-0.5 rounded {{ $backup->type === 'code' ? 'bg-blue-100 text-blue-700' : 'bg-rose-100 text-rose-700' }}">
                                {{ $backup->type === 'code' ? 'SOURCE CODE' : 'DATABASE' }}
                            </span>
                        </div>
                        <p class="text-xs font-black text-slate-800 truncate mb-1">{{ $backup->filename }}</p>
                        <p class="text-[10px] font-bold text-slate-400 uppercase">{{ $backup->formatted_size }} • {{ $backup->created_at->diffForHumans() }}</p>
                    </div>
                </div>
                @empty
                <div class="col-span-full py-20 text-center text-slate-400 italic">No hay snapshots disponibles.</div>
                @endforelse
            </div>
        </div>
    </div>
</div>

<script>
function healthMonitor() {
    return {
        metrics: {
            server: { cpu: 0, ram: { percent: 0 }, disk: { percent: 0 }, os: '' },
            database: { latency_ms: 0 },
            firebase: { latency_ms: 0 },
            services: [],
            queues: { pending: 0 }
        },
        file: null,
        packVersion: '{{ $currentVersion->version ?? "1.0.0" }}',
        packChangelog: '',
        updateLogs: [],
        systemLogs: 'Cargando logs...',
        init() {
            this.fetchMetrics();
            setInterval(() => this.fetchMetrics(), 5000);
            
            // Si el hash es #logs, cargar logs
            if (window.location.hash === '#logs') {
                this.tab = 'logs';
                this.fetchLogs();
            }
        },
        async fetchLogs() {
            try {
                const response = await fetch("{{ route('admin.updates.logs') }}");
                const data = await response.json();
                this.systemLogs = data.logs;
                
                // Auto-scroll al final
                setTimeout(() => {
                    const viewer = document.getElementById('log-viewer');
                    if (viewer) viewer.scrollTop = viewer.scrollHeight;
                }, 100);
            } catch (e) { this.systemLogs = 'Error al cargar los logs.'; }
        },
        async purgeSystem() {
            const result = await Swal.fire({
                title: '¿Ejecutar Limpieza?',
                text: 'Se borrarán archivos temporales y se limpiará la caché del sistema.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Sí, limpiar',
                confirmButtonColor: '#2563eb'
            });

            if (result.isConfirmed) {
                Swal.fire({ title: 'Limpiando...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
                try {
                    const response = await fetch("{{ route('admin.updates.purge') }}", {
                        method: 'POST',
                        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
                    });
                    const data = await response.json();
                    if (data.success) {
                        Swal.fire('¡Limpio!', data.message, 'success');
                    }
                } catch (e) { Swal.fire('Error', 'Fallo la limpieza', 'error'); }
            }
        },
        async generatePack() {
            const result = await Swal.fire({
                title: '¿Generar Nuevo Paquete?',
                text: 'Esto comprimirá el estado actual del sistema. Asegúrate de que los cambios estén listos.',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Sí, empaquetar',
                confirmButtonColor: '#2563eb'
            });

            if (result.isConfirmed) {
                Swal.fire({ title: 'Empaquetando...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
                try {
                    const response = await fetch("{{ route('admin.updates.pack') }}", {
                        method: 'POST',
                        headers: { 
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}' 
                        },
                        body: JSON.stringify({ 
                            version: this.packVersion,
                            changelog: this.packChangelog
                        })
                    });
                    const data = await response.json();
                    if (data.success) {
                        Swal.fire('Éxito', data.message, 'success').then(() => window.location.reload());
                    }
                } catch (e) { Swal.fire('Error', 'No se pudo generar el paquete', 'error'); }
            }
        },
        async fetchMetrics() {
            try {
                const response = await fetch("{{ route('admin.updates.health') }}");
                this.metrics = await response.json();
            } catch (e) { console.error('Error fetching metrics', e); }
        },
        handleFile(event) {
            this.file = event.target.files[0];
        },
        async uploadUpdate() {
            if (!this.file) return;
            
            const formData = new FormData();
            formData.append('update_file', this.file);

            Swal.fire({
                title: 'Validando Paquete',
                html: 'Analizando integridad del ZIP...',
                allowOutsideClick: false,
                didOpen: () => { Swal.showLoading() }
            });

            try {
                const response = await fetch("{{ route('admin.updates.upload') }}", {
                    method: 'POST',
                    headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                    body: formData
                });
                const data = await response.json();
                
                if (data.success) {
                    const result = await Swal.fire({
                        title: 'Paquete Validado',
                        text: 'El parche está listo. ¿Deseas aplicarlo ahora? El sistema entrará en modo mantenimiento.',
                        icon: 'info',
                        showCancelButton: true,
                        confirmButtonText: 'Sí, aplicar actualización',
                        confirmButtonColor: '#0f172a'
                    });

                    if (result.isConfirmed) {
                        this.applyUpdate(data.temp_path);
                    }
                } else {
                    throw new Error(data.message);
                }
            } catch (error) {
                Swal.fire('Error', error.message, 'error');
            }
        },
        async applyUpdate(tempPath, skipBackup = false) {
            this.updateLogs = ["🚀 Iniciando proceso de actualización..."];
            
            Swal.fire({
                title: skipBackup ? 'Aplicando (Sin Backup DB)' : 'Aplicando Actualización',
                html: `
                    <div class="mt-4 text-left">
                        <p class="text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest text-center">Consola de Despliegue</p>
                        <div id="update-console" class="bg-slate-900 rounded-2xl p-4 h-48 overflow-y-auto font-mono text-[10px] text-emerald-400 space-y-1">
                            <template x-for="log in updateLogs">
                                <div class="flex gap-2">
                                    <span class="text-slate-500">>></span>
                                    <span x-text="log"></span>
                                </div>
                            </template>
                        </div>
                    </div>
                `,
                allowOutsideClick: false,
                didOpen: () => { 
                    Swal.showLoading();
                }
            });

            const addLog = (msg) => {
                this.updateLogs.push(msg);
                const consoleDiv = document.getElementById('update-console');
                if (consoleDiv) {
                    const newLog = document.createElement('div');
                    newLog.className = 'flex gap-2';
                    newLog.innerHTML = `<span class="text-slate-500">>></span><span>${msg}</span>`;
                    consoleDiv.appendChild(newLog);
                    consoleDiv.scrollTop = consoleDiv.scrollHeight;
                }
            };

            try {
                const response = await fetch("{{ url('admin/updates/apply') }}", {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' 
                    },
                    body: JSON.stringify({ 
                        temp_path: tempPath,
                        skip_backup: skipBackup
                    })
                });
                const data = await response.json();

                if (data.logs) {
                    data.logs.forEach(log => addLog(log));
                }

                if (data.success) {
                    setTimeout(() => {
                        Swal.fire('¡Éxito!', data.message, 'success').then(() => window.location.reload());
                    }, 1000);
                } else {
                    if (data.message.includes('backup preventivo')) {
                        const result = await Swal.fire({
                            title: 'Fallo de Seguridad',
                            text: 'No pudimos crear el backup automático. ¿Deseas aplicar el parche de todas formas? (Riesgoso)',
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonText: 'Sí, aplicar sin backup',
                            cancelButtonText: 'No, cancelar',
                            confirmButtonColor: '#f59e0b'
                        });

                        if (result.isConfirmed) {
                            this.applyUpdate(tempPath, true);
                        }
                    } else {
                        throw new Error(data.message);
                    }
                }
            } catch (error) {
                Swal.fire('Fallo', error.message, 'error');
            }
        },
        async createBackup() {
            Swal.fire({ title: 'Creando Snapshot...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
            try {
                const response = await fetch("{{ route('admin.updates.backup') }}", {
                    method: 'POST',
                    headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
                });
                const data = await response.json();
                if (data.success) {
                    Swal.fire('Éxito', data.message, 'success').then(() => window.location.reload());
                }
            } catch (e) { Swal.fire('Error', 'No se pudo crear el backup', 'error'); }
        },
        async confirmRollback(id) {
            const result = await Swal.fire({
                title: '¿Confirmar Restauración?',
                text: 'Esta acción es irreversible.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Sí, Restaurar',
                confirmButtonColor: '#e11d48'
            });

            if (result.isConfirmed) {
                Swal.fire({ title: 'Restaurando...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
                try {
                    const response = await fetch(`{{ url('admin/updates/rollback') }}/${id}`, {
                        method: 'POST',
                        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
                    });
                    const data = await response.json();
                    if (data.success) {
                        Swal.fire('Restaurado', data.message, 'success').then(() => window.location.reload());
                    } else {
                        throw new Error(data.message);
                    }
                } catch (error) {
                    Swal.fire('Error', error.message, 'error');
                }
            }
        }
    }
}
</script>
@endsection
